import math
import os

def simulação_core_zie(qarg_list, auth_token=0, k_manual=None):
    """
    NÚCLEO HÍBRIDO EIE/ZIE - Versão Estudo Final
    Valida a transição entre Energia, Informação e Equilíbrio.
    """
    # Camada de Proteção: Sintonização por Fração Áurea
    PHI = (1 + 5**0.5) / 2
    ZIE_MASTER_KEY = PHI - 1 # 0.618033...
    
    if abs((auth_token / PHI) - ZIE_MASTER_KEY) > 1e-9:
        return None, None

    N = len(qarg_list)
    # K_ZIE: O parâmetro de controle que impede o colapso entrópico
    K_ZIE = k_manual if k_manual is not None else 0.15
    w_total = 0
    
    # 1. CÁLCULO DA ENERGIA DE CAMPO (Trabalho W)
    for i in range(N):
        # Assinatura de fase baseada em PHI
        e_qubit = math.sin(PHI * (i + 1)) 
        for j in range(i + 1, N):
            distancia = abs(i - j)
            # Lei de Potência Inversa Modulada
            interacao = (e_qubit * math.sin(PHI * (j + 1))) / (distancia**2 + 1)
            w_total += interacao * math.exp(-distancia * K_ZIE)

    # 2. MÉTRICA DE ESTABILIDADE TAU (z)
    densidade_e = abs(w_total) / N
    # A equação que unifica a escala L com a densidade energética
    tau_calculado = PHI + (math.log10(densidade_e + 1) * 0.5)

    # 3. LOG DE TELEMETRIA
    log_path = os.path.join(os.getcwd(), "zie_energy.log")
    try:
        with open(log_path, "a") as log:
            log.write(f"N={N:3d} | K={K_ZIE:.4f} | Z={tau_calculado:.6f}\n")
    except:
        pass
    
    return tau_calculado, densidade_e