import sys
import os

# Linkando a pasta src
sys.path.append(os.path.join(os.getcwd(), 'src'))

try:
    from zie_core import simulação_core_zie
except ImportError:
    print("\n[ERRO] Motor ZIE não encontrado na pasta /src!")
    sys.exit()

# CONFIGURAÇÃO DE ACESSO (Sabor Programação Quântica)
TOKEN = 1.0 
meus_qubits = [f"q{i}" for i in range(100)] # Teste com 100 elementos

print("\n" + "="*45)
print("   EIE/ZIE ENGINE - SISTEMA OPERACIONAL")
print("="*45)

# Execução do Núcleo com K sintonizado (0.2831 para máxima estabilidade)
tau, densidade = simulação_core_zie(meus_qubits, auth_token=TOKEN, k_manual=0.2831)

if tau:
    print(f"\n[SINTONIA] Harmonia estabelecida com o PHI.")
    print(f"[METRICA Z]: {tau:.6f}")
    
    status = "ZIE (Equilíbrio)" if densidade < 0.5 else "EIE (Desordem)"
    print(f"[ESTADO]   : {status}")
    print(f"[INFO]     : Sistema pronto para processamento híbrido.")
else:
    print("\n[ERRO] Falha de Sincronia. Verifique o Token.")

print("="*45 + "\n")